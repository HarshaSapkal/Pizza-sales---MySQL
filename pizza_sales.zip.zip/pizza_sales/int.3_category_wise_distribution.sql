-- find the category wise distribution of pizzas
select count(name) as name,category from pizza_types group by category;