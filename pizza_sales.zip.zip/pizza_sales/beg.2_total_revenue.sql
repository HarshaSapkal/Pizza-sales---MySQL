-- Calculate total revenue generated from pizza sales
SELECT 
    round(SUM(order_details.quantity * pizzas.price),2) AS Total_Revenue
FROM
    order_details
        JOIN
    pizzas ON order_details.pizza_id = pizzas.pizza_id;