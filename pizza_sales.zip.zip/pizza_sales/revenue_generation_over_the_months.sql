-- Revenue generation over the months
SELECT 
    MONTH(orders.order_date) AS mon,
    ROUND(SUM(order_details.quantity * pizzas.price),
            2) AS revenue
FROM
    orders
        JOIN
    order_details ON orders.order_id = order_details.order_id
        JOIN
    pizzas ON pizzas.pizza_id = order_details.pizza_id
GROUP BY mon
;