-- Determine the top 3 most ordered pizza types based on revenue
select sum(pizzas.price*order_details.quantity) as revenue , pizza_types.name
from pizzas join order_details
on pizzas.pizza_id = order_details.pizza_id
join pizza_types 
on pizzas.pizza_type_id = pizza_types.pizza_type_id
group by pizza_types.name
order by revenue desc 
limit 3;